# Быстрое развёртывание 🚀

Пошаговая инструкция для быстрого запуска системы.

## ⏱️ Время развёртывания: ~15 минут

## Шаг 1: Supabase (5 минут)

1. Откройте [supabase.com](https://supabase.com) → Sign up
2. Создайте новый проект:
   - Название: `perederzhka-spb`
   - Database Password: придумайте надёжный пароль
   - Region: выберите ближайший (Europe West для РФ)
3. Дождитесь создания проекта (~2 минуты)
4. Перейдите в **SQL Editor** (иконка слева)
5. Нажмите **New Query**
6. Скопируйте содержимое файла `supabase-schema.sql`
7. Вставьте и нажмите **Run**
8. Сохраните учётные данные:
   - Settings → API → Project URL
   - Settings → API → anon/public key

✅ База данных готова!

## Шаг 2: Установка проекта (3 минуты)

```bash
# Клонируйте репозиторий
git clone <your-repo-url>
cd perederzhka-spb

# Установите зависимости
npm install
```

## Шаг 3: Конфигурация (2 минуты)

Откройте `src/App.jsx` и замените на 8-9 строках:

```javascript
const SUPABASE_URL = 'https://ваш-проект.supabase.co';
const SUPABASE_ANON_KEY = 'ваш-анонимный-ключ';
```

## Шаг 4: Тестирование локально (2 минуты)

```bash
npm run dev
```

Откройте http://localhost:5173

✅ Проверьте:
- Календарь отображается
- Можно добавить собаку
- Можно создать бронь

## Шаг 5: Деплой на GitHub Pages (3 минуты)

### Вариант А: Автоматический деплой

1. Создайте репозиторий на GitHub
2. Пушните код:
```bash
git remote add origin https://github.com/your-username/perederzhka-spb.git
git add .
git commit -m "Initial commit"
git push -u origin main
```

3. Создайте файл `.github/workflows/deploy.yml`:
```bash
mkdir -p .github/workflows
```

Скопируйте содержимое из раздела "Деплой" в README.md

4. Включите GitHub Pages:
   - Репозиторий → Settings → Pages
   - Source: GitHub Actions
   - Сохраните

5. Пушните workflow:
```bash
git add .github/workflows/deploy.yml
git commit -m "Add deploy workflow"
git push
```

✅ Через 2-3 минуты сайт будет доступен на:
`https://your-username.github.io/perederzhka-spb/`

### Вариант Б: Ручной деплой

```bash
# Установите gh-pages
npm install -D gh-pages

# Добавьте в package.json в scripts:
"deploy": "npm run build && gh-pages -d dist"

# Обновите vite.config.js base:
base: '/perederzhka-spb/'

# Деплой
npm run deploy
```

Включите Pages в Settings → Pages → Source: gh-pages branch

## 🎉 Готово!

Ваша система развёрнута и работает!

## 🔧 Что дальше?

### Добавьте первую собаку:
1. Откройте вкладку "Собаки"
2. Нажмите "Добавить собаку"
3. Заполните данные

### Создайте первую бронь:
1. Откройте "Календарь"
2. Нажмите "+" внизу справа
3. Выберите собаку и даты

### Установите PWA на телефон:
1. Откройте сайт на телефоне
2. Нажмите "Добавить на домашний экран"
3. Готово! Работает как приложение

## 🆘 Проблемы?

### Не загружаются данные:
- Проверьте консоль браузера (F12)
- Убедитесь, что SUPABASE_URL и KEY правильные
- Проверьте, что SQL скрипт выполнился без ошибок

### Ошибка 404 после деплоя:
- Проверьте, что `base` в vite.config.js совпадает с именем репозитория
- Убедитесь, что GitHub Pages включён

### Не работает PWA:
- Добавьте иконки (см. PWA_ICONS.md)
- Пересоберите: `npm run build`
- Очистите кеш браузера

## 📱 Мобильная оптимизация

Уже включена! Работает на:
- ✅ iOS (Safari)
- ✅ Android (Chrome)
- ✅ Desktop (все браузеры)

## 🔒 Безопасность для продакшена

⚠️ **ВАЖНО**: Текущая версия без авторизации!

Для продакшена обязательно:
1. Включите RLS в Supabase
2. Добавьте аутентификацию
3. Ограничьте доступ к анонимному ключу

См. IMPROVEMENTS.md для деталей.

---

**Нужна помощь?** Проверьте README.md или консоль браузера для ошибок.
