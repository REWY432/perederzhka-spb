# Структура проекта Perederzhka SPB

```
perederzhka-spb/
│
├── public/                          # Статические файлы
│   └── favicon.svg                  # Иконка приложения
│
├── src/                             # Исходный код
│   ├── main.jsx                     # Точка входа приложения
│   ├── App.jsx                      # Главный компонент (все функции здесь)
│   ├── App.css                      # Стили компонентов
│   └── index.css                    # Глобальные стили и glassmorphism
│
├── .github/
│   └── workflows/
│       └── deploy.yml               # ⚠️ Создать для автодеплоя
│
├── .env.example                     # Пример конфигурации
├── .gitignore                       # Игнорируемые файлы
├── index.html                       # HTML шаблон
├── package.json                     # Зависимости проекта
├── vite.config.js                   # Конфигурация Vite + PWA
├── supabase-schema.sql              # SQL схема базы данных
│
├── README.md                        # Основная документация
├── QUICK_START.md                   # Быстрый старт
├── IMPROVEMENTS.md                  # Идеи для улучшений
└── PWA_ICONS.md                     # Инструкции по иконкам

```

## 📁 Описание файлов

### Основные файлы для редактирования:

#### `src/App.jsx` - Главный файл приложения
- ✅ Все компоненты и логика
- ✅ Подключение к Supabase
- ✅ CRUD операции
- ⚠️ ИЗМЕНИТЕ: SUPABASE_URL и SUPABASE_ANON_KEY (строки 8-9)

#### `src/App.css` - Стили компонентов
- ✅ Glassmorphism дизайн
- ✅ Адаптивная вёрстка
- ✅ Анимации и эффекты

#### `src/index.css` - Глобальные стили
- ✅ Цветовая схема
- ✅ Типография
- ✅ Базовые стили

#### `vite.config.js` - Конфигурация сборки
- ✅ React plugin
- ✅ PWA plugin
- ⚠️ ИЗМЕНИТЕ: `base` на имя вашего репозитория

#### `supabase-schema.sql` - База данных
- ✅ Таблицы: dogs, bookings, expenses
- ✅ Индексы и триггеры
- ✅ Row Level Security

### Файлы для деплоя:

#### `.github/workflows/deploy.yml`
⚠️ **НУЖНО СОЗДАТЬ** для автоматического деплоя
Скопируйте содержимое из README.md

### Документация:

- **README.md** - Полная документация
- **QUICK_START.md** - Пошаговое развёртывание за 15 минут
- **IMPROVEMENTS.md** - Идеи для расширения функционала
- **PWA_ICONS.md** - Как создать иконки для PWA

## 🎯 Что нужно сделать перед деплоем:

### 1. Обязательно:
- [ ] Выполнить `supabase-schema.sql` в Supabase
- [ ] Заменить SUPABASE_URL и SUPABASE_ANON_KEY в `src/App.jsx`
- [ ] Изменить `base` в `vite.config.js` на имя репозитория
- [ ] Установить зависимости: `npm install`

### 2. Опционально (но рекомендуется):
- [ ] Создать иконки для PWA (192x192, 512x512, 180x180)
- [ ] Создать `.github/workflows/deploy.yml` для автодеплоя
- [ ] Настроить домен (если нужен свой)

### 3. Для продакшена:
- [ ] Включить RLS в Supabase
- [ ] Добавить аутентификацию
- [ ] Настроить CORS
- [ ] Добавить мониторинг ошибок

## 🚀 Команды для работы:

```bash
# Установка зависимостей
npm install

# Запуск dev сервера
npm run dev

# Сборка для продакшена
npm run build

# Превью production сборки
npm run preview

# Деплой на GitHub Pages (после настройки gh-pages)
npm run deploy
```

## 📦 Зависимости:

### Production:
- **react** - UI библиотека
- **@supabase/supabase-js** - База данных
- **date-fns** - Работа с датами
- **lucide-react** - Иконки

### Development:
- **vite** - Сборщик
- **@vitejs/plugin-react** - React плагин
- **vite-plugin-pwa** - PWA функционал

## 🎨 Кастомизация:

### Цвета (в `src/index.css`):
```css
--accent-blue: #4c9aff;      /* Основной синий */
--accent-purple: #9d5fff;    /* Дополнительный фиолетовый */
--accent-pink: #ff5fa2;      /* Акцентный розовый */
```

### Базовые цены (в `src/App.jsx`):
```javascript
const BASE_PRICES = {
  small: 1500,   // Малые породы
  medium: 2000,  // Средние породы
  large: 3000    // Большие породы
};
```

### Название (в нескольких местах):
- `package.json` - "name"
- `index.html` - <title>
- `vite.config.js` - manifest.name
- `src/App.jsx` - логотип в Header

## 🔍 Решение проблем:

### Ошибка "Cannot read property of undefined":
→ Проверьте SUPABASE_URL и SUPABASE_ANON_KEY

### 404 после деплоя:
→ Проверьте `base` в vite.config.js

### Данные не сохраняются:
→ Убедитесь, что SQL схема выполнена в Supabase

### PWA не устанавливается:
→ Добавьте иконки в папку public

## 💡 Совет:

Начните с QUICK_START.md - там пошаговая инструкция на 15 минут!

---

**Успехов с запуском!** 🚀🐕
